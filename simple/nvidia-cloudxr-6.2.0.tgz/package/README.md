# NVIDIA CloudXR.js

CloudXR.js is a JavaScript SDK for building WebXR clients that stream high-performance VR/AR content from CloudXR OpenXR Runtime servers. It integrates browser-based applications with remote rendering so immersive experiences run on server GPUs while remaining easy to deploy and access as web apps.

The SDK provides session management, signaling/media integration, and a framework-agnostic client API. It can be used with custom WebXR stacks and includes reference sample workflows based on WebGL and React Three Fiber.

Current client support is focused on Meta Quest and Pico class devices (with desktop browsers supported for development and testing workflows).

## Documentation and Quick Start

- [CloudXR.js User Guide](https://docs.nvidia.com/cloudxr-sdk/latest/usr_guide/cloudxr_js/index.html)
  - [CloudXR Quick Start](https://docs.nvidia.com/cloudxr-sdk/latest/quickstart.html)
  - Sample client workflows: [WebGL sample](https://docs.nvidia.com/cloudxr-sdk/latest/usr_guide/cloudxr_js/sample_webgl.html), [React sample](https://docs.nvidia.com/cloudxr-sdk/latest/usr_guide/cloudxr_js/sample_react.html)
- [CloudXR.js APIs](https://docs.nvidia.com/cloudxr-sdk/apis/cloudxr-js/latest/)

## License

This project is licensed under the NVIDIA CloudXR License. See `LICENSE` for terms.
